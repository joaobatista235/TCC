-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 01-Dez-2020 às 16:29
-- Versão do servidor: 10.4.14-MariaDB
-- versão do PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sistema_aca`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categorias`
--

CREATE TABLE `categorias` (
  `CatId` int(1) NOT NULL,
  `CatDescricao` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `categorias`
--

INSERT INTO `categorias` (`CatId`, `CatDescricao`) VALUES
(1, 'administrador'),
(2, 'visitante');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mensagens`
--

CREATE TABLE `mensagens` (
  `idMensagem` int(11) NOT NULL,
  `id_de` int(10) NOT NULL,
  `id_para` int(10) NOT NULL,
  `mensagem` varchar(200) NOT NULL,
  `visualizada` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoas`
--

CREATE TABLE `pessoas` (
  `PesId` int(10) NOT NULL,
  `PesNome` varchar(100) NOT NULL,
  `PesTelefone` varchar(14) NOT NULL,
  `PesEmail` varchar(100) NOT NULL,
  `PesSenha` varchar(100) NOT NULL,
  `PesCPF` varchar(14) NOT NULL,
  `PesCategoria` int(1) NOT NULL,
  `PesRegiao` varchar(50) NOT NULL,
  `PesImagem` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `pessoas`
--

INSERT INTO `pessoas` (`PesId`, `PesNome`, `PesTelefone`, `PesEmail`, `PesSenha`, `PesCPF`, `PesCategoria`, `PesRegiao`, `PesImagem`) VALUES
(1, 'João Batista', '(15)99839-4854', 'juniorbatista0404@gmail.com', 'Winteriscoming', '378.725.958-93', 1, '', 'Pessoas/1_6e7a6287b0e4e18398041cefbfcd9d5f.jpg'),
(29, 'José Gabriel', '(15)98124-0037', 'bielserafim39@gmail.com', 'paubrasil', '448.236.078-30', 2, '', 'Pessoas/29_d452a1335dc6e39f07c2df6002927bb1.jpg'),
(30, 'Mariane Oliveira', '(15)99696-4473', 'marianewalker2233@gmail.com', '123456', '534.550.308-74', 2, '', 'Pessoas/30_e0fb4ba51f37777373fd56396eadb8a3.jpeg'),
(64, 'Alexandre Rodrigues Júnior', '(15)99835-0023', 'al860270@gmail.com', 'junior45', '487.609.638-40', 2, '', ''),
(65, 'Manuela Jaqueline Alves', '(66)98716-0346', 'manuela27@gmail.com', 'manu1203', '444.490.597-27', 2, '', 'Pessoas/65_6936d8928689c10ab6f012c4a2f30d1b.jpg'),
(66, 'Evelyn Tatiane Galvão', '(15)99908-6741', 'evelyntatianegalvao@vemarbrasil.com.br', '4eZ1WAofIF', '239.857.114-96', 2, '', 'Pessoas/66_146631170c36393ab83180b932b24ec1.jpg'),
(67, 'Murilo Pedro dos Santos', '(15)99940-1246', 'murilopedrodossantos79@gmail.com.br', 'gaiHaqrg5N', '975.015.025-28', 2, '', 'Pessoas/67_dd345860adaf66562a7ac05a001298dc.jpg'),
(68, 'Antonio Marcelo Caldeira', '(15)99899-7129', 'aantoniomarcelocaldeira@gmail.com.br', 'F9dknntY1X', '084.611.726-63', 2, '', 'Pessoas/68_63dbfb07020d3cfb7bbd81857180c69d.jpg'),
(69, 'Antonio Martin Viana', '(15)29989-0408', 'antoniomartinviana@hotmail.com.br', 'JTxwYCSTM5', '516.025.916-36', 2, '', ''),
(70, 'Flávia Olivia Kamilly Ribeiro', '(15)69856-7209', 'flaviaoliviakamillyribeiro82@hotmail.com.br', 'bbgJW6hDQn', '447.943.731-20', 2, '', ''),
(71, 'Kaique Enzo da Mata', '(15)99641-3258', 'kaiquemata@gmail.com', 'DHz8cnopN2', '259.386.252-11', 2, '', ''),
(72, 'Bruno Gael da Paz', '(15)99986-5242', 'bbrunogaeldapaz@emerson.com', '7SUjheFn6S', '805.226.215-11', 2, '', ''),
(73, 'João Cláudio Vieira', '(15) 99371-665', 'joaoclaudiovieira-87@heindmec.com.br', 'OH1zk97EgM', '541.145.248-19', 2, '', ''),
(74, 'Melissa Luana Nunes', '(15) 99888-656', 'melissaluananunes@gmail.com.br', '4Ooh7JlfU9', '674.051.378-30', 2, '', ''),
(75, 'Helena Josefa Cláudia Ribeiro', '(15) 98624-304', 'helenajosefaclaudiaribeiro@hotmail.com', 'IhfKc9A6QU', '094.842.378-19', 2, '', ''),
(76, 'Cláudio André Pereira', '(15) 98879-979', 'claudioandrepereira@gmail.com.br', '0SAdk9ygBr', '039.629.398-06', 2, '', ''),
(77, 'Maya Fabiana Silva', '(15) 98158-724', 'mayafabianasilva_@adherminer.com.br', 't3M9zAz3W1', '297.803.098-45', 2, '', ''),
(78, 'Vanessa Sophia Lavínia Nogueira', '(15) 99759-416', 'vanessasophialavinianogueira@hotmail.com.br', '0oax5apQQD', '929.838.318-50', 2, '', ''),
(79, 'Bernardo Felipe Corte Real', '(15) 99712-088', 'bernardofelipecortereal_@anfip.org.br', 'eeOqckdjF0', '661.193.718-85', 2, '', ''),
(80, 'Nathan Lucas Hugo Almada', '(15) 99358-384', 'nathanlucashugoalmada_@dhl.com', 'keM0UJEtjB', '289.234.978-86', 2, '', ''),
(81, 'Fernanda Sueli Novaes', '(15) 98610-405', 'fernandasuelinovaes_@vnews.com.br', 'JTpr98wuxL', '562.078.408-87', 2, '', ''),
(82, 'Renato Mateus da Mata', '(15) 99697-164', 'renatomateusdamata@bds.com.br', 'J6USnJHkj3', '766.555.178-50', 2, '', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `ProdId` int(11) NOT NULL,
  `ProdImg` text DEFAULT NULL,
  `ProdEmail` varchar(100) NOT NULL,
  `ProdTitulo` varchar(100) NOT NULL,
  `ProdEndereco` varchar(100) NOT NULL,
  `ProdRegiao` varchar(1) NOT NULL,
  `ProdTipo` varchar(50) NOT NULL,
  `ProdDesc` text NOT NULL,
  `ProdStatus` varchar(1) NOT NULL,
  `ProdProprietario` int(10) NOT NULL,
  `HorarioDePostagem` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`ProdId`, `ProdImg`, `ProdEmail`, `ProdTitulo`, `ProdEndereco`, `ProdRegiao`, `ProdTipo`, `ProdDesc`, `ProdStatus`, `ProdProprietario`, `HorarioDePostagem`) VALUES
(33, 'Produtos/65_b097558abc03afe535ec644edfffa7c1.png', 'manuela27@gmail.com', 'Cenoura', 'Rua Renato de Souza Faria', '1', '1', '', 'N', 65, '2020-11-28 00:35:26'),
(34, 'Produtos/65_30cfb523c0241c57d5b87e9f14019914.png', 'manuela27@gmail.com', 'Semente de girassol', 'Rua Renato de Souza Faria', '1', '1', 'Semente de girassol de qualidade', 'S', 65, '2020-11-27 02:12:13'),
(35, 'Produtos/66_65d0ae7dffdf05350293879ac8ad047d.png', 'evelyntatianegalvao@vemarbrasil.com.br', 'Repolho roxo', 'Bairro S Judas Tadeu, Rua Angelo Guazélli', '2', '3', 'Repolho roxo de altíssima qualidade e sem agrotóxicos', 'S', 66, '2020-11-27 02:22:14'),
(36, 'Produtos/66_cf889dafe5f48c8e5e63728956c61e0b.png', 'evelyntatianegalvao@vemarbrasil.com.br', 'Pá', 'Bairro S Judas Tadeu, Rua Angelo Guazélli', '2', '2', 'Pá ótima para cavar', 'S', 66, '2020-11-27 02:27:09'),
(37, 'Produtos/66_cadb84cc675b5983ba726b35bf7313f8.png', 'evelyntatianegalvao@vemarbrasil.com.br', 'Salsinha', 'Bairro S Judas Tadeu, Rua Angelo Guazélli', '2', '3', 'Salsinha de boa qualidade', 'S', 66, '2020-11-27 02:28:55'),
(38, 'Produtos/67_c4720ad50916a56b5e48edf2f905e54f.png', 'murilopedrodossantos79@gmail.com.br', 'Regador', 'Rua Altino Arantes 918 Jardim Sumaré', '3', '2', 'Regador bom', 'S', 67, '2020-11-27 02:36:51'),
(39, 'Produtos/67_9bf10776a006dc403afd71cef2709011.png', 'murilopedrodossantos79@gmail.com.br', 'Semente de Nabo', 'Rua Altino Arantes 918 Jardim Sumaré', '3', '1', 'Semente de Nabo de altíssima qualidade', 'S', 67, '2020-11-27 02:39:31'),
(41, 'Produtos/67_5d8cd9f5c10ca0027fbc675fb1962b1d.png', 'murilopedrodossantos79@gmail.com.br', 'Pêssego', 'Rua Altino Arantes 918 Jardim Sumaré', '3', '3', 'Pêssego bom sem agrotóxico', 'S', 67, '2020-11-27 02:45:37'),
(42, 'Produtos/68_1aa439e1fb60c98331cf7ea585a69359.png', 'aantoniomarcelocaldeira@gmail.com.br', 'Motosserra', 'Bairro Central Park Rua João Batista Vieira', '1', '2', 'Motoserra boa', 'S', 68, '2020-11-27 02:54:47');

-- --------------------------------------------------------

--
-- Estrutura da tabela `regiao`
--

CREATE TABLE `regiao` (
  `RegiaoId` int(11) NOT NULL,
  `RegiaoNome` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `regiao`
--

INSERT INTO `regiao` (`RegiaoId`, `RegiaoNome`) VALUES
(1, 'Itapeva'),
(2, 'Buri'),
(3, 'Ribeirão');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipoprodutos`
--

CREATE TABLE `tipoprodutos` (
  `TipoId` int(11) NOT NULL,
  `TipoDesc` varchar(100) NOT NULL,
  `TipoNome` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tipoprodutos`
--

INSERT INTO `tipoprodutos` (`TipoId`, `TipoDesc`, `TipoNome`) VALUES
(1, '', 'Sementes'),
(2, '', 'Ferramentas'),
(3, '', 'Colhidos');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`CatId`);

--
-- Índices para tabela `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`idMensagem`);

--
-- Índices para tabela `pessoas`
--
ALTER TABLE `pessoas`
  ADD PRIMARY KEY (`PesId`),
  ADD UNIQUE KEY `PesCPF` (`PesCPF`);

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`ProdId`),
  ADD KEY `pessoa_id_fk` (`ProdProprietario`);

--
-- Índices para tabela `regiao`
--
ALTER TABLE `regiao`
  ADD PRIMARY KEY (`RegiaoId`);

--
-- Índices para tabela `tipoprodutos`
--
ALTER TABLE `tipoprodutos`
  ADD PRIMARY KEY (`TipoId`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `CatId` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `mensagens`
--
ALTER TABLE `mensagens`
  MODIFY `idMensagem` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pessoas`
--
ALTER TABLE `pessoas`
  MODIFY `PesId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `ProdId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT de tabela `regiao`
--
ALTER TABLE `regiao`
  MODIFY `RegiaoId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `tipoprodutos`
--
ALTER TABLE `tipoprodutos`
  MODIFY `TipoId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `produtos`
--
ALTER TABLE `produtos`
  ADD CONSTRAINT `fk_produto_pessoa` FOREIGN KEY (`ProdProprietario`) REFERENCES `pessoas` (`PesId`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
